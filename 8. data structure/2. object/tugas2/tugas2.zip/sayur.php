<?php

class Sayur {
   
    public $apakahBusuk;


}

$s = new Sayur();
//$s->beli();
//$s->apakahBusuk();
